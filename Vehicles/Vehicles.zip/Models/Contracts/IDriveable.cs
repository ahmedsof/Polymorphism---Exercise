﻿

namespace Vehicles.Models.Contracts
{
    public interface IDriveable
    {
        string Drive(double amount);
    }
}
